from database.db import get_connection
from typing import Optional, List


# =====================
# GUILD SETTINGS
# =====================

def get_guild_settings(guild_id: str) -> dict:
    conn = get_connection()
    row = conn.execute("SELECT * FROM guild_settings WHERE guild_id = ?", (guild_id,)).fetchone()
    if not row:
        conn.execute("INSERT OR IGNORE INTO guild_settings (guild_id, prefix) VALUES (?, '$')", (guild_id,))
        conn.commit()
        row = conn.execute("SELECT * FROM guild_settings WHERE guild_id = ?", (guild_id,)).fetchone()
    conn.close()
    return dict(row)


def get_prefix(guild_id: str) -> str:
    conn = get_connection()
    row = conn.execute("SELECT prefix FROM guild_settings WHERE guild_id = ?", (guild_id,)).fetchone()
    conn.close()
    return row["prefix"] if row else "$"


def set_prefix(guild_id: str, prefix: str):
    conn = get_connection()
    conn.execute(
        "INSERT INTO guild_settings (guild_id, prefix) VALUES (?, ?) ON CONFLICT(guild_id) DO UPDATE SET prefix = ?, updated_at = strftime('%s', 'now')",
        (guild_id, prefix, prefix),
    )
    conn.commit()
    conn.close()


def set_log_channel(guild_id: str, channel_id: str):
    get_guild_settings(guild_id)
    conn = get_connection()
    conn.execute(
        "UPDATE guild_settings SET log_channel = ?, updated_at = strftime('%s', 'now') WHERE guild_id = ?",
        (channel_id, guild_id),
    )
    conn.commit()
    conn.close()


def set_welcome_channel(guild_id: str, channel_id: str, message: Optional[str] = None):
    get_guild_settings(guild_id)
    conn = get_connection()
    conn.execute(
        "UPDATE guild_settings SET welcome_channel = ?, welcome_message = ?, updated_at = strftime('%s', 'now') WHERE guild_id = ?",
        (channel_id, message, guild_id),
    )
    conn.commit()
    conn.close()


def set_leave_channel(guild_id: str, channel_id: str, message: Optional[str] = None):
    get_guild_settings(guild_id)
    conn = get_connection()
    conn.execute(
        "UPDATE guild_settings SET leave_channel = ?, leave_message = ?, updated_at = strftime('%s', 'now') WHERE guild_id = ?",
        (channel_id, message, guild_id),
    )
    conn.commit()
    conn.close()


def update_automod(guild_id: str, **kwargs):
    get_guild_settings(guild_id)
    allowed = {"anti_spam", "anti_link", "bad_words_filter", "bad_words", "spam_threshold", "spam_interval"}
    updates = {k: v for k, v in kwargs.items() if k in allowed}
    if not updates:
        return
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    values = list(updates.values()) + [guild_id]
    conn = get_connection()
    conn.execute(f"UPDATE guild_settings SET {set_clause}, updated_at = strftime('%s', 'now') WHERE guild_id = ?", values)
    conn.commit()
    conn.close()


# =====================
# WARNINGS
# =====================

def add_warning(guild_id: str, user_id: str, moderator_id: str, reason: str) -> int:
    conn = get_connection()
    cursor = conn.execute(
        "INSERT INTO warnings (guild_id, user_id, moderator_id, reason) VALUES (?, ?, ?, ?)",
        (guild_id, user_id, moderator_id, reason),
    )
    conn.commit()
    warn_id = cursor.lastrowid
    conn.close()
    return warn_id


def get_warnings(guild_id: str, user_id: str) -> List[dict]:
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM warnings WHERE guild_id = ? AND user_id = ? ORDER BY created_at ASC",
        (guild_id, user_id),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_warning_count(guild_id: str, user_id: str) -> int:
    conn = get_connection()
    row = conn.execute(
        "SELECT COUNT(*) as count FROM warnings WHERE guild_id = ? AND user_id = ?",
        (guild_id, user_id),
    ).fetchone()
    conn.close()
    return row["count"] if row else 0


def clear_warnings(guild_id: str, user_id: str) -> int:
    conn = get_connection()
    cursor = conn.execute(
        "DELETE FROM warnings WHERE guild_id = ? AND user_id = ?", (guild_id, user_id)
    )
    conn.commit()
    changes = cursor.rowcount
    conn.close()
    return changes


def remove_warning(warn_id: int, guild_id: str) -> int:
    conn = get_connection()
    cursor = conn.execute(
        "DELETE FROM warnings WHERE id = ? AND guild_id = ?", (warn_id, guild_id)
    )
    conn.commit()
    changes = cursor.rowcount
    conn.close()
    return changes


# =====================
# TICKETS
# =====================

def get_ticket_settings(guild_id: str) -> dict:
    conn = get_connection()
    row = conn.execute("SELECT * FROM ticket_settings WHERE guild_id = ?", (guild_id,)).fetchone()
    if not row:
        conn.execute("INSERT OR IGNORE INTO ticket_settings (guild_id) VALUES (?)", (guild_id,))
        conn.commit()
        row = conn.execute("SELECT * FROM ticket_settings WHERE guild_id = ?", (guild_id,)).fetchone()
    conn.close()
    return dict(row)


def set_ticket_settings(guild_id: str, **kwargs):
    get_ticket_settings(guild_id)
    allowed = {"category_id", "support_role", "ticket_channel"}
    updates = {k: v for k, v in kwargs.items() if k in allowed}
    if not updates:
        return
    set_clause = ", ".join(f"{k} = ?" for k in updates)
    values = list(updates.values()) + [guild_id]
    conn = get_connection()
    conn.execute(f"UPDATE ticket_settings SET {set_clause} WHERE guild_id = ?", values)
    conn.commit()
    conn.close()


def get_ticket_count(guild_id: str) -> int:
    conn = get_connection()
    conn.execute("INSERT OR IGNORE INTO ticket_settings (guild_id) VALUES (?)", (guild_id,))
    conn.execute(
        "UPDATE ticket_settings SET ticket_count = ticket_count + 1 WHERE guild_id = ?", (guild_id,)
    )
    conn.commit()
    row = conn.execute("SELECT ticket_count FROM ticket_settings WHERE guild_id = ?", (guild_id,)).fetchone()
    conn.close()
    return row["ticket_count"] if row else 1


def create_ticket(guild_id: str, channel_id: str, user_id: str):
    conn = get_connection()
    conn.execute(
        "INSERT INTO tickets (guild_id, channel_id, user_id) VALUES (?, ?, ?)",
        (guild_id, channel_id, user_id),
    )
    conn.commit()
    conn.close()


def get_ticket_by_channel(channel_id: str) -> Optional[dict]:
    conn = get_connection()
    row = conn.execute("SELECT * FROM tickets WHERE channel_id = ?", (channel_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def get_open_ticket_by_user(guild_id: str, user_id: str) -> Optional[dict]:
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM tickets WHERE guild_id = ? AND user_id = ? AND status = 'open'",
        (guild_id, user_id),
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def close_ticket(channel_id: str):
    conn = get_connection()
    conn.execute(
        "UPDATE tickets SET status = 'closed', closed_at = strftime('%s', 'now') WHERE channel_id = ?",
        (channel_id,),
    )
    conn.commit()
    conn.close()


# =====================
# REACTION ROLES
# =====================

def add_reaction_role(guild_id: str, message_id: str, channel_id: str, emoji: str, role_id: str):
    conn = get_connection()
    conn.execute(
        "INSERT OR REPLACE INTO reaction_roles (guild_id, message_id, channel_id, emoji, role_id) VALUES (?, ?, ?, ?, ?)",
        (guild_id, message_id, channel_id, emoji, role_id),
    )
    conn.commit()
    conn.close()


def get_reaction_role(guild_id: str, message_id: str, emoji: str) -> Optional[dict]:
    conn = get_connection()
    row = conn.execute(
        "SELECT * FROM reaction_roles WHERE guild_id = ? AND message_id = ? AND emoji = ?",
        (guild_id, message_id, emoji),
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def get_reaction_roles(guild_id: str, message_id: str) -> List[dict]:
    conn = get_connection()
    rows = conn.execute(
        "SELECT * FROM reaction_roles WHERE guild_id = ? AND message_id = ?",
        (guild_id, message_id),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def remove_reaction_role(guild_id: str, message_id: str, emoji: str):
    conn = get_connection()
    conn.execute(
        "DELETE FROM reaction_roles WHERE guild_id = ? AND message_id = ? AND emoji = ?",
        (guild_id, message_id, emoji),
    )
    conn.commit()
    conn.close()
