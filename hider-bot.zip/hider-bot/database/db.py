import sqlite3
import os
from utils.logger import logger

# Ensure data directory exists
DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
os.makedirs(DATA_DIR, exist_ok=True)

DB_PATH = os.path.join(DATA_DIR, "hider_bot.db")


def get_connection() -> sqlite3.Connection:
    """Get a database connection with row factory."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    """Initialize all database tables."""
    conn = get_connection()
    cursor = conn.cursor()

    cursor.executescript("""
        CREATE TABLE IF NOT EXISTS guild_settings (
            guild_id TEXT PRIMARY KEY,
            prefix TEXT NOT NULL DEFAULT '$',
            log_channel TEXT,
            welcome_channel TEXT,
            leave_channel TEXT,
            welcome_message TEXT,
            leave_message TEXT,
            anti_spam INTEGER DEFAULT 1,
            anti_link INTEGER DEFAULT 0,
            bad_words_filter INTEGER DEFAULT 0,
            bad_words TEXT DEFAULT '',
            spam_threshold INTEGER DEFAULT 5,
            spam_interval INTEGER DEFAULT 5,
            created_at INTEGER DEFAULT (strftime('%s', 'now')),
            updated_at INTEGER DEFAULT (strftime('%s', 'now'))
        );

        CREATE TABLE IF NOT EXISTS warnings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            moderator_id TEXT NOT NULL,
            reason TEXT NOT NULL,
            created_at INTEGER DEFAULT (strftime('%s', 'now'))
        );

        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id TEXT NOT NULL,
            channel_id TEXT NOT NULL UNIQUE,
            user_id TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'open',
            created_at INTEGER DEFAULT (strftime('%s', 'now')),
            closed_at INTEGER
        );

        CREATE TABLE IF NOT EXISTS ticket_settings (
            guild_id TEXT PRIMARY KEY,
            category_id TEXT,
            support_role TEXT,
            ticket_channel TEXT,
            ticket_count INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS reaction_roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id TEXT NOT NULL,
            message_id TEXT NOT NULL,
            channel_id TEXT NOT NULL,
            emoji TEXT NOT NULL,
            role_id TEXT NOT NULL,
            UNIQUE(guild_id, message_id, emoji)
        );
    """)

    conn.commit()
    conn.close()
    logger.info("Database initialized successfully.")


# Initialize on import
init_db()
