import discord
from discord.ext import commands
from database.queries import get_prefix


CATEGORIES = {
    "Moderation": {
        "description": "Commands for managing and moderating members.",
        "commands": [
            ("ban", "Ban a member from the server."),
            ("kick", "Kick a member from the server."),
            ("timeout", "Timeout a member for X minutes."),
            ("warn", "Issue a warning to a member."),
            ("warnings", "View all warnings for a member."),
            ("clearwarns", "Clear all warnings for a member."),
            ("removewarn", "Remove a warning by its ID."),
            ("clear", "Delete up to 100 messages at once."),
            ("unban", "Unban a user by their ID."),
        ],
    },
    "Utility": {
        "description": "General-purpose utility commands.",
        "commands": [
            ("ping", "Show the bot's current latency."),
            ("serverinfo", "Display detailed server information."),
            ("userinfo", "Display information about a member."),
            ("avatar", "Show a member's avatar."),
        ],
    },
    "Configuration": {
        "description": "Configure the bot for your server.",
        "commands": [
            ("prefix", "Change or view the server prefix."),
            ("setlog", "Set the moderation log channel."),
            ("setwelcome", "Set the welcome channel and message."),
            ("setleave", "Set the leave channel and message."),
            ("automod", "Toggle anti-spam, anti-link, bad words."),
            ("setbadwords", "Set the bad words list."),
            ("settings", "View all current server settings."),
        ],
    },
    "Systems": {
        "description": "Advanced systems like tickets and reaction roles.",
        "commands": [
            ("ticketsetup", "Send the ticket panel to a channel."),
            ("reactionrole", "Add a reaction role to a message."),
            ("removereactionrole", "Remove a reaction role."),
            ("reactionroles", "List reaction roles on a message."),
        ],
    },
}


class CategorySelect(discord.ui.Select):
    def __init__(self, prefix: str):
        self.prefix = prefix
        options = [
            discord.SelectOption(label=name, description=data["description"][:50])
            for name, data in CATEGORIES.items()
        ]
        super().__init__(
            placeholder="Select a category...",
            min_values=1,
            max_values=1,
            options=options,
        )

    async def callback(self, interaction: discord.Interaction):
        category = self.values[0]
        data = CATEGORIES[category]
        prefix = self.prefix

        embed = discord.Embed(
            title=f"{category}",
            description=data["description"],
            color=0x5865F2,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_footer(text="Made by jesuislechef21")

        for name, desc in data["commands"]:
            embed.add_field(
                name=f"`{prefix}{name}`",
                value=desc,
                inline=True,
            )

        await interaction.response.edit_message(embed=embed, view=self.view)


class HelpView(discord.ui.View):
    def __init__(self, prefix: str):
        super().__init__(timeout=60)
        self.add_item(CategorySelect(prefix))

    async def on_timeout(self):
        for item in self.children:
            item.disabled = True


class Help(commands.Cog, name="Help"):
    def __init__(self, bot):
        self.bot = bot
        self.bot.help_command = None

    @commands.command(name="help", usage="!help")
    @commands.guild_only()
    async def help(self, ctx):
        """Show the interactive help menu."""
        prefix = get_prefix(str(ctx.guild.id))

        embed = discord.Embed(
            title="Hider Bot",
            description=f"Select a category below to view its commands.\nPrefix: `{prefix}`",
            color=0x5865F2,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_footer(text="Made by jesuislechef21")

        categories_text = "\n".join(
            f"**{name}** — {data['description']}" for name, data in CATEGORIES.items()
        )
        embed.add_field(name="Categories", value=categories_text, inline=False)

        view = HelpView(prefix)
        await ctx.reply(embed=embed, view=view)


async def setup(bot):
    await bot.add_cog(Help(bot))
