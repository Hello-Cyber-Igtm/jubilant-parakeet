import discord
from discord.ext import commands
from database.queries import (
    set_prefix, set_log_channel, set_welcome_channel, set_leave_channel, update_automod,
    get_guild_settings, set_ticket_settings
)
from utils.embed import success_embed, error_embed, info_embed


class Config(commands.Cog, name="Config"):
    """Server configuration commands."""

    def __init__(self, bot):
        self.bot = bot

    # ─── Prefix ───────────────────────────────────────────────────────────────

    @commands.command(name="prefix", usage="!prefix <new_prefix>")
    @commands.guild_only()
    async def prefix(self, ctx, new_prefix: str = None):
        """Change the bot's prefix for this server."""
        if not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply(embed=error_embed("You need the **Manage Server** permission to change the prefix."))
        if new_prefix is None:
            settings = get_guild_settings(str(ctx.guild.id))
            return await ctx.reply(embed=info_embed(f"The current prefix is `{settings['prefix']}`.", "Server Prefix"))
        if len(new_prefix) > 5:
            return await ctx.reply(embed=error_embed("The prefix cannot be longer than **5** characters."))

        set_prefix(str(ctx.guild.id), new_prefix)
        await ctx.reply(embed=success_embed(f"The server prefix has been updated to `{new_prefix}`.", "Prefix Updated"))

    # ─── Set Log Channel ──────────────────────────────────────────────────────

    @commands.command(name="setlog", usage="!setlog <#channel>")
    @commands.guild_only()
    async def setlog(self, ctx, channel: discord.TextChannel = None):
        """Set the moderation log channel."""
        if not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply(embed=error_embed("You need the **Manage Server** permission."))
        if channel is None:
            return await ctx.reply(embed=error_embed("Please mention a channel.\n**Usage:** `!setlog <#channel>`"))

        set_log_channel(str(ctx.guild.id), str(channel.id))
        await ctx.reply(embed=success_embed(f"Moderation logs will now be sent to {channel.mention}.", "Log Channel Set"))

    # ─── Set Welcome Channel ──────────────────────────────────────────────────

    @commands.command(name="setwelcome", usage="!setwelcome <#channel> [message]")
    @commands.guild_only()
    async def setwelcome(self, ctx, channel: discord.TextChannel = None, *, message: str = None):
        """Set the welcome channel and optional message. Use {user}, {username}, {server}, {count}."""
        if not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply(embed=error_embed("You need the **Manage Server** permission."))
        if channel is None:
            return await ctx.reply(embed=error_embed("Please mention a channel.\n**Usage:** `!setwelcome <#channel> [message]`"))

        set_welcome_channel(str(ctx.guild.id), str(channel.id), message)
        desc = f"Welcome messages will be sent to {channel.mention}."
        if message:
            desc += f"\n**Message:** {message}"
        await ctx.reply(embed=success_embed(desc, "Welcome Channel Set"))

    # ─── Set Leave Channel ────────────────────────────────────────────────────

    @commands.command(name="setleave", usage="!setleave <#channel> [message]")
    @commands.guild_only()
    async def setleave(self, ctx, channel: discord.TextChannel = None, *, message: str = None):
        """Set the leave channel and optional message."""
        if not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply(embed=error_embed("You need the **Manage Server** permission."))
        if channel is None:
            return await ctx.reply(embed=error_embed("Please mention a channel.\n**Usage:** `!setleave <#channel> [message]`"))

        set_leave_channel(str(ctx.guild.id), str(channel.id), message)
        desc = f"Leave messages will be sent to {channel.mention}."
        if message:
            desc += f"\n**Message:** {message}"
        await ctx.reply(embed=success_embed(desc, "Leave Channel Set"))

    # ─── Auto-Mod Settings ────────────────────────────────────────────────────

    @commands.command(name="automod", usage="!automod <setting> <on/off>")
    @commands.guild_only()
    async def automod(self, ctx, setting: str = None, value: str = None):
        """Configure auto-moderation settings.

        Settings: antispam, antilink, badwords
        """
        if not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply(embed=error_embed("You need the **Manage Server** permission."))

        valid = {"antispam": "anti_spam", "antilink": "anti_link", "badwords": "bad_words_filter"}

        if setting is None or setting.lower() not in valid:
            settings = get_guild_settings(str(ctx.guild.id))
            embed = discord.Embed(title="Auto-Moderation Settings", color=0x5865F2, timestamp=discord.utils.utcnow())
            embed.set_footer(text="Made by jesuislechef21")
            embed.add_field(name="Anti-Spam", value="Enabled" if settings["anti_spam"] else "Disabled", inline=True)
            embed.add_field(name="Anti-Link", value="Enabled" if settings["anti_link"] else "Disabled", inline=True)
            embed.add_field(name="Bad Words Filter", value="Enabled" if settings["bad_words_filter"] else "Disabled", inline=True)
            embed.description = "Use `!automod <antispam|antilink|badwords> <on|off>` to toggle."
            return await ctx.reply(embed=embed)

        if value is None or value.lower() not in ("on", "off", "true", "false", "1", "0"):
            return await ctx.reply(embed=error_embed("Please provide `on` or `off`.\n**Usage:** `!automod <setting> <on/off>`"))

        enabled = value.lower() in ("on", "true", "1")
        db_key = valid[setting.lower()]
        update_automod(str(ctx.guild.id), **{db_key: 1 if enabled else 0})
        state = "enabled" if enabled else "disabled"
        await ctx.reply(embed=success_embed(f"**{setting.capitalize()}** has been {state}.", "Auto-Mod Updated"))

    # ─── Set Bad Words ────────────────────────────────────────────────────────

    @commands.command(name="setbadwords", usage="!setbadwords <word1,word2,...>")
    @commands.guild_only()
    async def setbadwords(self, ctx, *, words: str = None):
        """Set the list of banned words (comma-separated)."""
        if not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply(embed=error_embed("You need the **Manage Server** permission."))
        if words is None:
            return await ctx.reply(embed=error_embed("Please provide a comma-separated list of words.\n**Usage:** `!setbadwords word1,word2,word3`"))

        update_automod(str(ctx.guild.id), bad_words=words)
        count = len([w.strip() for w in words.split(",") if w.strip()])
        await ctx.reply(embed=success_embed(f"Bad words list updated with **{count}** word(s).", "Bad Words Updated"))

    # ─── Ticket Setup ─────────────────────────────────────────────────────────

    @commands.command(name="ticketsetup", usage="!ticketsetup <#channel> [category_id] [@support_role]")
    @commands.guild_only()
    async def ticketsetup(self, ctx, channel: discord.TextChannel = None, category: discord.CategoryChannel = None, role: discord.Role = None):
        """Set up the ticket system and send the ticket panel to a channel."""
        if not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply(embed=error_embed("You need the **Manage Server** permission."))
        if channel is None:
            return await ctx.reply(embed=error_embed("Please mention a channel.\n**Usage:** `!ticketsetup <#channel> [category] [@role]`"))

        kwargs = {"ticket_channel": str(channel.id)}
        if category:
            kwargs["category_id"] = str(category.id)
        if role:
            kwargs["support_role"] = str(role.id)

        set_ticket_settings(str(ctx.guild.id), **kwargs)

        # Send ticket panel
        embed = discord.Embed(
            title="Support Tickets",
            description="Click the button below to open a support ticket. A private channel will be created for you.",
            color=0x5865F2,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_footer(text="Made by jesuislechef21")

        view = discord.ui.View(timeout=None)
        open_btn = discord.ui.Button(label="Open Ticket", style=discord.ButtonStyle.primary, custom_id="ticket_open")
        view.add_item(open_btn)

        await channel.send(embed=embed, view=view)
        await ctx.reply(embed=success_embed(f"Ticket panel has been sent to {channel.mention}.", "Ticket System Ready"))

    # ─── Settings Overview ────────────────────────────────────────────────────

    @commands.command(name="settings", usage="!settings")
    @commands.guild_only()
    async def settings(self, ctx):
        """View all current settings for this server."""
        if not ctx.author.guild_permissions.manage_guild:
            return await ctx.reply(embed=error_embed("You need the **Manage Server** permission."))

        s = get_guild_settings(str(ctx.guild.id))

        def ch(cid):
            return f"<#{cid}>" if cid else "Not set"

        embed = discord.Embed(title=f"Settings for {ctx.guild.name}", color=0x5865F2, timestamp=discord.utils.utcnow())
        embed.set_thumbnail(url=ctx.guild.icon.url if ctx.guild.icon else None)
        embed.set_footer(text="Made by jesuislechef21")
        embed.add_field(name="Prefix", value=f"`{s['prefix']}`", inline=True)
        embed.add_field(name="Log Channel", value=ch(s["log_channel"]), inline=True)
        embed.add_field(name="Welcome Channel", value=ch(s["welcome_channel"]), inline=True)
        embed.add_field(name="Leave Channel", value=ch(s["leave_channel"]), inline=True)
        embed.add_field(name="Anti-Spam", value="Enabled" if s["anti_spam"] else "Disabled", inline=True)
        embed.add_field(name="Anti-Link", value="Enabled" if s["anti_link"] else "Disabled", inline=True)
        embed.add_field(name="Bad Words Filter", value="Enabled" if s["bad_words_filter"] else "Disabled", inline=True)

        await ctx.reply(embed=embed)


async def setup(bot):
    await bot.add_cog(Config(bot))
