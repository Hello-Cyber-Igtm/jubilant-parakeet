import discord
from discord.ext import commands
from database.queries import (
    add_reaction_role, get_reaction_roles, remove_reaction_role
)
from utils.embed import success_embed, error_embed, info_embed


class Systems(commands.Cog, name="Systems"):
    """Advanced server systems — reaction roles and more."""

    def __init__(self, bot):
        self.bot = bot

    # ─── Reaction Role: Add ───────────────────────────────────────────────────

    @commands.command(name="reactionrole", aliases=["rr"], usage="!reactionrole <message_id> <emoji> <@role>")
    @commands.guild_only()
    async def reactionrole(self, ctx, message_id: str = None, emoji: str = None, role: discord.Role = None):
        """Add a reaction role to a message."""
        if not ctx.author.guild_permissions.manage_roles:
            return await ctx.reply(embed=error_embed("You need the **Manage Roles** permission."))
        if not message_id or not emoji or not role:
            return await ctx.reply(embed=error_embed(
                "**Usage:** `!reactionrole <message_id> <emoji> <@role>`\n"
                "The message must be in this channel."
            ))

        # Verify the message exists
        try:
            msg = await ctx.channel.fetch_message(int(message_id))
        except (discord.NotFound, ValueError):
            return await ctx.reply(embed=error_embed("Message not found in this channel. Make sure you use a message ID from this channel."))

        # Check bot role hierarchy
        if role >= ctx.guild.me.top_role:
            return await ctx.reply(embed=error_embed("I cannot assign a role that is equal to or higher than my highest role."))
        if role >= ctx.author.top_role and ctx.author.id != ctx.guild.owner_id:
            return await ctx.reply(embed=error_embed("You cannot assign a role that is equal to or higher than your highest role."))

        add_reaction_role(str(ctx.guild.id), str(msg.id), str(ctx.channel.id), emoji, str(role.id))

        # Add the reaction to the message
        try:
            await msg.add_reaction(emoji)
        except discord.HTTPException:
            return await ctx.reply(embed=error_embed("I could not add that emoji reaction. Make sure the emoji is valid."))

        await ctx.reply(embed=success_embed(
            f"Reaction role added.\n**Message:** [Jump]({msg.jump_url})\n**Emoji:** {emoji}\n**Role:** {role.mention}",
            "Reaction Role Added"
        ))

    # ─── Reaction Role: Remove ────────────────────────────────────────────────

    @commands.command(name="removereactionrole", aliases=["rrr"], usage="!removereactionrole <message_id> <emoji>")
    @commands.guild_only()
    async def removereactionrole(self, ctx, message_id: str = None, emoji: str = None):
        """Remove a reaction role from a message."""
        if not ctx.author.guild_permissions.manage_roles:
            return await ctx.reply(embed=error_embed("You need the **Manage Roles** permission."))
        if not message_id or not emoji:
            return await ctx.reply(embed=error_embed("**Usage:** `!removereactionrole <message_id> <emoji>`"))

        remove_reaction_role(str(ctx.guild.id), message_id, emoji)
        await ctx.reply(embed=success_embed(f"Reaction role for emoji **{emoji}** removed from message `{message_id}`.", "Reaction Role Removed"))

    # ─── Reaction Role: List ──────────────────────────────────────────────────

    @commands.command(name="reactionroles", usage="!reactionroles <message_id>")
    @commands.guild_only()
    async def reactionroles(self, ctx, message_id: str = None):
        """List all reaction roles for a message."""
        if not ctx.author.guild_permissions.manage_roles:
            return await ctx.reply(embed=error_embed("You need the **Manage Roles** permission."))
        if not message_id:
            return await ctx.reply(embed=error_embed("**Usage:** `!reactionroles <message_id>`"))

        roles = get_reaction_roles(str(ctx.guild.id), message_id)
        if not roles:
            return await ctx.reply(embed=info_embed("No reaction roles configured for that message.", "No Reaction Roles"))

        embed = discord.Embed(
            title="Reaction Roles",
            color=0x5865F2,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_footer(text="Made by jesuislechef21")
        for rr in roles:
            role = ctx.guild.get_role(int(rr["role_id"]))
            embed.add_field(
                name=f"Emoji: {rr['emoji']}",
                value=role.mention if role else f"Unknown Role (`{rr['role_id']}`)",
                inline=True,
            )
        await ctx.reply(embed=embed)


async def setup(bot):
    await bot.add_cog(Systems(bot))
