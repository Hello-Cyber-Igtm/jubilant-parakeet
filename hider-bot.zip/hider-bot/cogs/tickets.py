import discord
from discord.ext import commands
from database.queries import (
    get_ticket_settings, get_ticket_count, create_ticket,
    get_ticket_by_channel, get_open_ticket_by_user, close_ticket
)
from utils.embed import error_embed, success_embed
from utils.logger import logger


class Tickets(commands.Cog, name="Tickets"):
    """Ticket system for user support."""

    def __init__(self, bot):
        self.bot = bot

    # ─── Internal: Open Ticket ────────────────────────────────────────────────

    async def open_ticket(self, interaction: discord.Interaction):
        """Handle ticket open button interaction."""
        await interaction.response.defer(ephemeral=True)
        guild = interaction.guild
        user = interaction.user

        if not guild:
            return await interaction.followup.send(
                embed=error_embed("This can only be used in a server."), ephemeral=True
            )

        # Check for existing open ticket
        existing = get_open_ticket_by_user(str(guild.id), str(user.id))
        if existing:
            ch = guild.get_channel(int(existing["channel_id"]))
            if ch:
                return await interaction.followup.send(
                    embed=error_embed(f"You already have an open ticket: {ch.mention}"), ephemeral=True
                )

        settings = get_ticket_settings(str(guild.id))
        ticket_count = get_ticket_count(str(guild.id))
        channel_name = f"ticket-{ticket_count:04d}"

        # Determine category
        category = None
        if settings.get("category_id"):
            category = guild.get_channel(int(settings["category_id"]))

        # Set up overwrites
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True),
        }

        # Add support role if configured
        if settings.get("support_role"):
            support_role = guild.get_role(int(settings["support_role"]))
            if support_role:
                overwrites[support_role] = discord.PermissionOverwrite(view_channel=True, send_messages=True)

        try:
            ticket_channel = await guild.create_text_channel(
                name=channel_name,
                category=category,
                overwrites=overwrites,
                topic=f"Ticket for {user} ({user.id})",
            )
        except discord.Forbidden:
            return await interaction.followup.send(
                embed=error_embed("I do not have permission to create channels."), ephemeral=True
            )
        except Exception as e:
            logger.error(f"Failed to create ticket channel: {e}")
            return await interaction.followup.send(
                embed=error_embed("Failed to create ticket channel. Please contact an administrator."), ephemeral=True
            )

        create_ticket(str(guild.id), str(ticket_channel.id), str(user.id))

        # Send welcome message in ticket channel
        embed = discord.Embed(
            title=f"Ticket #{ticket_count:04d}",
            description=(
                f"Welcome, {user.mention}.\n\n"
                "Please describe your issue and a staff member will assist you shortly.\n"
                "Click **Close Ticket** when your issue has been resolved."
            ),
            color=0x5865F2,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_footer(text="Made by jesuislechef21")

        view = discord.ui.View(timeout=None)
        close_btn = discord.ui.Button(label="Close Ticket", style=discord.ButtonStyle.danger, custom_id="ticket_close")
        view.add_item(close_btn)

        await ticket_channel.send(content=user.mention, embed=embed, view=view)
        await interaction.followup.send(
            embed=success_embed(f"Your ticket has been created: {ticket_channel.mention}", "Ticket Opened"),
            ephemeral=True,
        )

    # ─── Internal: Close Ticket ───────────────────────────────────────────────

    async def close_ticket_action(self, interaction: discord.Interaction):
        """Handle ticket close button interaction."""
        await interaction.response.defer()
        guild = interaction.guild
        channel = interaction.channel

        if not guild:
            return

        ticket = get_ticket_by_channel(str(channel.id))
        if not ticket:
            return await interaction.followup.send(
                embed=error_embed("This is not a recognized ticket channel."), ephemeral=True
            )
        if ticket["status"] == "closed":
            return await interaction.followup.send(
                embed=error_embed("This ticket is already closed."), ephemeral=True
            )

        # Only allow the ticket owner or staff with manage channels to close
        is_owner = str(interaction.user.id) == ticket["user_id"]
        is_staff = interaction.user.guild_permissions.manage_channels

        if not is_owner and not is_staff:
            return await interaction.followup.send(
                embed=error_embed("Only the ticket creator or staff can close this ticket."), ephemeral=True
            )

        close_ticket(str(channel.id))

        embed = discord.Embed(
            title="Ticket Closed",
            description=f"This ticket was closed by {interaction.user.mention}.\nThis channel will be deleted in **5 seconds**.",
            color=0xED4245,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_footer(text="Made by jesuislechef21")
        await channel.send(embed=embed)

        import asyncio
        await asyncio.sleep(5)
        try:
            await channel.delete(reason=f"Ticket closed by {interaction.user}")
        except Exception as e:
            logger.error(f"Failed to delete ticket channel: {e}")


async def setup(bot):
    await bot.add_cog(Tickets(bot))
