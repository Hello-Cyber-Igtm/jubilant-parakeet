import discord
from discord.ext import commands
from datetime import datetime
from utils.embed import info_embed, error_embed, base_embed, Colors


class Utility(commands.Cog, name="Utility"):
    """Utility commands for general server use."""

    def __init__(self, bot):
        self.bot = bot

    # ─── Ping ─────────────────────────────────────────────────────────────────

    @commands.command(name="ping", usage="!ping")
    @commands.guild_only()
    async def ping(self, ctx):
        """Check the bot's latency."""
        latency = round(self.bot.latency * 1000)
        embed = base_embed(
            color=Colors.PRIMARY,
            title="Pong",
            description=f"Websocket latency: **{latency}ms**",
        )
        await ctx.reply(embed=embed)

    # ─── Server Info ──────────────────────────────────────────────────────────

    @commands.command(name="serverinfo", aliases=["guildinfo"], usage="!serverinfo")
    @commands.guild_only()
    async def serverinfo(self, ctx):
        """Display detailed information about the server."""
        guild = ctx.guild
        owner = guild.owner

        # Count channels
        text_channels = len(guild.text_channels)
        voice_channels = len(guild.voice_channels)
        categories = len(guild.categories)

        # Member stats
        total_members = guild.member_count
        bots = sum(1 for m in guild.members if m.bot)
        humans = total_members - bots

        embed = discord.Embed(
            title=guild.name,
            color=Colors.PRIMARY,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_footer(text="Made by jesuislechef21")

        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)
        if guild.banner:
            embed.set_image(url=guild.banner.url)

        embed.add_field(name="Owner", value=str(owner) if owner else "Unknown", inline=True)
        embed.add_field(name="Server ID", value=str(guild.id), inline=True)
        embed.add_field(name="Region", value="Global", inline=True)
        embed.add_field(name="Members", value=f"Total: {total_members}\nHumans: {humans}\nBots: {bots}", inline=True)
        embed.add_field(name="Channels", value=f"Text: {text_channels}\nVoice: {voice_channels}\nCategories: {categories}", inline=True)
        embed.add_field(name="Roles", value=str(len(guild.roles) - 1), inline=True)
        embed.add_field(name="Emojis", value=f"{len(guild.emojis)}/{guild.emoji_limit}", inline=True)
        embed.add_field(name="Verification Level", value=str(guild.verification_level).replace("_", " ").title(), inline=True)
        embed.add_field(name="Boost Level", value=f"Level {guild.premium_tier} ({guild.premium_subscription_count} boosts)", inline=True)
        embed.add_field(name="Created At", value=f"<t:{int(guild.created_at.timestamp())}:F>", inline=False)

        await ctx.reply(embed=embed)

    # ─── User Info ────────────────────────────────────────────────────────────

    @commands.command(name="userinfo", aliases=["whois"], usage="!userinfo [member]")
    @commands.guild_only()
    async def userinfo(self, ctx, member: discord.Member = None):
        """Display detailed information about a member."""
        member = member or ctx.author

        # Collect roles (exclude @everyone)
        roles = [r.mention for r in reversed(member.roles) if r.name != "@everyone"]
        roles_text = " ".join(roles[:10]) if roles else "None"
        if len(roles) > 10:
            roles_text += f" and {len(roles) - 10} more"

        status_map = {
            discord.Status.online: "Online",
            discord.Status.idle: "Idle",
            discord.Status.dnd: "Do Not Disturb",
            discord.Status.offline: "Offline",
        }

        embed = discord.Embed(
            title=str(member),
            color=member.color if member.color != discord.Color.default() else Colors.PRIMARY,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text=f"User ID: {member.id} | Made by jesuislechef21")

        embed.add_field(name="Nickname", value=member.nick or "None", inline=True)
        embed.add_field(name="Status", value=status_map.get(member.status, "Unknown"), inline=True)
        embed.add_field(name="Bot", value="Yes" if member.bot else "No", inline=True)
        embed.add_field(name="Account Created", value=f"<t:{int(member.created_at.timestamp())}:F>", inline=True)
        embed.add_field(name="Joined Server", value=f"<t:{int(member.joined_at.timestamp())}:F>" if member.joined_at else "Unknown", inline=True)
        embed.add_field(name="Boosting Since", value=f"<t:{int(member.premium_since.timestamp())}:F>" if member.premium_since else "Not boosting", inline=True)
        embed.add_field(name=f"Roles ({len(roles)})", value=roles_text, inline=False)
        embed.add_field(name="Top Role", value=member.top_role.mention, inline=True)

        await ctx.reply(embed=embed)

    # ─── Avatar ───────────────────────────────────────────────────────────────

    @commands.command(name="avatar", aliases=["av"], usage="!avatar [member]")
    @commands.guild_only()
    async def avatar(self, ctx, member: discord.Member = None):
        """Display a member's avatar."""
        member = member or ctx.author
        embed = discord.Embed(
            title=f"{member}'s Avatar",
            color=Colors.PRIMARY,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_image(url=member.display_avatar.url)
        embed.set_footer(text="Made by jesuislechef21")
        await ctx.reply(embed=embed)


async def setup(bot):
    await bot.add_cog(Utility(bot))
