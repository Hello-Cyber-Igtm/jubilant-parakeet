import discord
from discord.ext import commands
from datetime import timedelta
from database.queries import (
    add_warning, get_warnings, get_warning_count, clear_warnings, remove_warning
)
from systems.mod_log import send_log_message
from utils.embed import success_embed, error_embed, moderation_embed
from utils.permissions import can_moderate, bot_can_moderate, send_no_permission
import time


class Moderation(commands.Cog, name="Moderation"):
    """Moderation commands for server management."""

    def __init__(self, bot):
        self.bot = bot

    # ─── Ban ──────────────────────────────────────────────────────────────────

    @commands.command(name="ban", usage="!ban <member> [reason]")
    @commands.guild_only()
    async def ban(self, ctx, member: discord.Member = None, *, reason: str = "No reason provided."):
        """Ban a member from the server."""
        if not ctx.author.guild_permissions.ban_members:
            return await send_no_permission(ctx, "Ban Members")
        if member is None:
            return await ctx.reply(embed=error_embed("Please specify a member to ban.\n**Usage:** `!ban <member> [reason]`"))
        if not can_moderate(ctx.author, member):
            return await ctx.reply(embed=error_embed("You cannot ban this member due to role hierarchy."))
        if not bot_can_moderate(ctx.guild.me, member):
            return await ctx.reply(embed=error_embed("I cannot ban this member due to role hierarchy."))

        try:
            try:
                await member.send(embed=discord.Embed(
                    title="You Have Been Banned",
                    description=f"You were banned from **{ctx.guild.name}**.\n**Reason:** {reason}",
                    color=0xED4245,
                ).set_footer(text="Made by jesuislechef21"))
            except Exception:
                pass

            await member.ban(reason=f"{ctx.author} | {reason}", delete_message_days=0)
            embed = moderation_embed(
                "Member Banned",
                fields=[
                    {"name": "User", "value": f"{member} (`{member.id}`)", "inline": True},
                    {"name": "Moderator", "value": str(ctx.author), "inline": True},
                    {"name": "Reason", "value": reason, "inline": False},
                ],
            )
            await ctx.reply(embed=embed)
            await send_log_message(ctx.guild, "Member Banned", color=0xED4245, fields=[
                {"name": "User", "value": f"{member} (`{member.id}`)", "inline": True},
                {"name": "Moderator", "value": str(ctx.author), "inline": True},
                {"name": "Reason", "value": reason, "inline": False},
            ], thumbnail=member.display_avatar.url)
        except discord.Forbidden:
            await ctx.reply(embed=error_embed("I do not have permission to ban that member."))
        except Exception as e:
            await ctx.reply(embed=error_embed(f"An error occurred: {e}"))

    # ─── Kick ─────────────────────────────────────────────────────────────────

    @commands.command(name="kick", usage="!kick <member> [reason]")
    @commands.guild_only()
    async def kick(self, ctx, member: discord.Member = None, *, reason: str = "No reason provided."):
        """Kick a member from the server."""
        if not ctx.author.guild_permissions.kick_members:
            return await send_no_permission(ctx, "Kick Members")
        if member is None:
            return await ctx.reply(embed=error_embed("Please specify a member to kick.\n**Usage:** `!kick <member> [reason]`"))
        if not can_moderate(ctx.author, member):
            return await ctx.reply(embed=error_embed("You cannot kick this member due to role hierarchy."))
        if not bot_can_moderate(ctx.guild.me, member):
            return await ctx.reply(embed=error_embed("I cannot kick this member due to role hierarchy."))

        try:
            try:
                await member.send(embed=discord.Embed(
                    title="You Have Been Kicked",
                    description=f"You were kicked from **{ctx.guild.name}**.\n**Reason:** {reason}",
                    color=0xED4245,
                ).set_footer(text="Made by jesuislechef21"))
            except Exception:
                pass

            await member.kick(reason=f"{ctx.author} | {reason}")
            embed = moderation_embed(
                "Member Kicked",
                fields=[
                    {"name": "User", "value": f"{member} (`{member.id}`)", "inline": True},
                    {"name": "Moderator", "value": str(ctx.author), "inline": True},
                    {"name": "Reason", "value": reason, "inline": False},
                ],
            )
            await ctx.reply(embed=embed)
            await send_log_message(ctx.guild, "Member Kicked", color=0xFF5733, fields=[
                {"name": "User", "value": f"{member} (`{member.id}`)", "inline": True},
                {"name": "Moderator", "value": str(ctx.author), "inline": True},
                {"name": "Reason", "value": reason, "inline": False},
            ], thumbnail=member.display_avatar.url)
        except discord.Forbidden:
            await ctx.reply(embed=error_embed("I do not have permission to kick that member."))
        except Exception as e:
            await ctx.reply(embed=error_embed(f"An error occurred: {e}"))

    # ─── Timeout ──────────────────────────────────────────────────────────────

    @commands.command(name="timeout", usage="!timeout <member> <minutes> [reason]")
    @commands.guild_only()
    async def timeout(self, ctx, member: discord.Member = None, minutes: int = None, *, reason: str = "No reason provided."):
        """Timeout a member for a specified number of minutes."""
        if not ctx.author.guild_permissions.moderate_members:
            return await send_no_permission(ctx, "Moderate Members")
        if member is None or minutes is None:
            return await ctx.reply(embed=error_embed("**Usage:** `!timeout <member> <minutes> [reason]`"))
        if minutes < 1 or minutes > 40320:
            return await ctx.reply(embed=error_embed("Timeout duration must be between **1** and **40320** minutes (28 days)."))
        if not can_moderate(ctx.author, member):
            return await ctx.reply(embed=error_embed("You cannot timeout this member due to role hierarchy."))

        try:
            duration = timedelta(minutes=minutes)
            await member.timeout(duration, reason=f"{ctx.author} | {reason}")
            embed = moderation_embed(
                "Member Timed Out",
                fields=[
                    {"name": "User", "value": f"{member} (`{member.id}`)", "inline": True},
                    {"name": "Moderator", "value": str(ctx.author), "inline": True},
                    {"name": "Duration", "value": f"{minutes} minute(s)", "inline": True},
                    {"name": "Reason", "value": reason, "inline": False},
                ],
            )
            await ctx.reply(embed=embed)
            await send_log_message(ctx.guild, "Member Timed Out", color=0xFEE75C, fields=[
                {"name": "User", "value": f"{member} (`{member.id}`)", "inline": True},
                {"name": "Moderator", "value": str(ctx.author), "inline": True},
                {"name": "Duration", "value": f"{minutes} minute(s)", "inline": True},
                {"name": "Reason", "value": reason, "inline": False},
            ])
        except discord.Forbidden:
            await ctx.reply(embed=error_embed("I do not have permission to timeout that member."))
        except Exception as e:
            await ctx.reply(embed=error_embed(f"An error occurred: {e}"))

    # ─── Warn ─────────────────────────────────────────────────────────────────

    @commands.command(name="warn", usage="!warn <member> [reason]")
    @commands.guild_only()
    async def warn(self, ctx, member: discord.Member = None, *, reason: str = "No reason provided."):
        """Warn a member and store it in the database."""
        if not ctx.author.guild_permissions.manage_messages:
            return await send_no_permission(ctx, "Manage Messages")
        if member is None:
            return await ctx.reply(embed=error_embed("Please specify a member to warn.\n**Usage:** `!warn <member> [reason]`"))
        if member.bot:
            return await ctx.reply(embed=error_embed("You cannot warn a bot."))
        if not can_moderate(ctx.author, member):
            return await ctx.reply(embed=error_embed("You cannot warn this member due to role hierarchy."))

        warn_id = add_warning(str(ctx.guild.id), str(member.id), str(ctx.author.id), reason)
        count = get_warning_count(str(ctx.guild.id), str(member.id))

        try:
            await member.send(embed=discord.Embed(
                title="You Have Been Warned",
                description=f"You received a warning in **{ctx.guild.name}**.\n**Reason:** {reason}\n**Total Warnings:** {count}",
                color=0xFEE75C,
            ).set_footer(text="Made by jesuislechef21"))
        except Exception:
            pass

        embed = moderation_embed(
            "Member Warned",
            fields=[
                {"name": "User", "value": f"{member} (`{member.id}`)", "inline": True},
                {"name": "Moderator", "value": str(ctx.author), "inline": True},
                {"name": "Warning ID", "value": str(warn_id), "inline": True},
                {"name": "Total Warnings", "value": str(count), "inline": True},
                {"name": "Reason", "value": reason, "inline": False},
            ],
        )
        await ctx.reply(embed=embed)
        await send_log_message(ctx.guild, "Member Warned", color=0xFEE75C, fields=[
            {"name": "User", "value": f"{member} (`{member.id}`)", "inline": True},
            {"name": "Moderator", "value": str(ctx.author), "inline": True},
            {"name": "Warning ID", "value": str(warn_id), "inline": True},
            {"name": "Total Warnings", "value": str(count), "inline": True},
            {"name": "Reason", "value": reason, "inline": False},
        ])

    # ─── Warnings ─────────────────────────────────────────────────────────────

    @commands.command(name="warnings", usage="!warnings <member>")
    @commands.guild_only()
    async def warnings(self, ctx, member: discord.Member = None):
        """View all warnings for a member."""
        if not ctx.author.guild_permissions.manage_messages:
            return await send_no_permission(ctx, "Manage Messages")
        if member is None:
            return await ctx.reply(embed=error_embed("Please specify a member.\n**Usage:** `!warnings <member>`"))

        warns = get_warnings(str(ctx.guild.id), str(member.id))
        if not warns:
            return await ctx.reply(embed=success_embed(f"{member.mention} has no warnings.", "No Warnings"))

        embed = discord.Embed(
            title=f"Warnings for {member}",
            color=0xFEE75C,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text="Made by jesuislechef21")

        for warn in warns[-10:]:  # Show last 10
            ts = f"<t:{warn['created_at']}:R>" if warn["created_at"] else "Unknown"
            embed.add_field(
                name=f"Warning #{warn['id']}",
                value=f"**Reason:** {warn['reason']}\n**Moderator:** <@{warn['moderator_id']}>\n**Date:** {ts}",
                inline=False,
            )

        if len(warns) > 10:
            embed.description = f"Showing last 10 of {len(warns)} total warnings."

        await ctx.reply(embed=embed)

    # ─── Clear Warnings ───────────────────────────────────────────────────────

    @commands.command(name="clearwarns", aliases=["clearwarnings"], usage="!clearwarns <member>")
    @commands.guild_only()
    async def clearwarns(self, ctx, member: discord.Member = None):
        """Clear all warnings for a member."""
        if not ctx.author.guild_permissions.manage_guild:
            return await send_no_permission(ctx, "Manage Server")
        if member is None:
            return await ctx.reply(embed=error_embed("Please specify a member.\n**Usage:** `!clearwarns <member>`"))

        count = clear_warnings(str(ctx.guild.id), str(member.id))
        await ctx.reply(embed=success_embed(f"Cleared **{count}** warning(s) from {member.mention}.", "Warnings Cleared"))

    # ─── Remove Warning ───────────────────────────────────────────────────────

    @commands.command(name="removewarn", usage="!removewarn <id>")
    @commands.guild_only()
    async def removewarn(self, ctx, warn_id: int = None):
        """Remove a specific warning by ID."""
        if not ctx.author.guild_permissions.manage_messages:
            return await send_no_permission(ctx, "Manage Messages")
        if warn_id is None:
            return await ctx.reply(embed=error_embed("Please provide a warning ID.\n**Usage:** `!removewarn <id>`"))

        changes = remove_warning(warn_id, str(ctx.guild.id))
        if changes:
            await ctx.reply(embed=success_embed(f"Warning **#{warn_id}** has been removed.", "Warning Removed"))
        else:
            await ctx.reply(embed=error_embed(f"No warning with ID **#{warn_id}** was found in this server."))

    # ─── Clear ────────────────────────────────────────────────────────────────

    @commands.command(name="clear", aliases=["purge"], usage="!clear <amount>")
    @commands.guild_only()
    async def clear(self, ctx, amount: int = None):
        """Delete a number of messages from the current channel."""
        if not ctx.author.guild_permissions.manage_messages:
            return await send_no_permission(ctx, "Manage Messages")
        if amount is None or amount < 1:
            return await ctx.reply(embed=error_embed("Please provide a valid number of messages to delete.\n**Usage:** `!clear <amount>`"))
        if amount > 100:
            return await ctx.reply(embed=error_embed("You can only delete up to **100** messages at a time."))

        try:
            deleted = await ctx.channel.purge(limit=amount + 1)
            count = len(deleted) - 1
            msg = await ctx.send(embed=success_embed(f"Deleted **{count}** message(s).", "Messages Cleared"))
            import asyncio
            await asyncio.sleep(4)
            await msg.delete()
        except discord.Forbidden:
            await ctx.reply(embed=error_embed("I do not have permission to delete messages."))
        except Exception as e:
            await ctx.reply(embed=error_embed(f"An error occurred: {e}"))

    # ─── Unban ────────────────────────────────────────────────────────────────

    @commands.command(name="unban", usage="!unban <user_id> [reason]")
    @commands.guild_only()
    async def unban(self, ctx, user_id: str = None, *, reason: str = "No reason provided."):
        """Unban a user by their ID."""
        if not ctx.author.guild_permissions.ban_members:
            return await send_no_permission(ctx, "Ban Members")
        if user_id is None:
            return await ctx.reply(embed=error_embed("Please provide a user ID.\n**Usage:** `!unban <user_id> [reason]`"))

        try:
            user = discord.Object(id=int(user_id))
            await ctx.guild.unban(user, reason=f"{ctx.author} | {reason}")
            await ctx.reply(embed=success_embed(f"User `{user_id}` has been unbanned.\n**Reason:** {reason}", "Member Unbanned"))
        except discord.NotFound:
            await ctx.reply(embed=error_embed("That user is not banned or does not exist."))
        except ValueError:
            await ctx.reply(embed=error_embed("Please provide a valid user ID."))
        except Exception as e:
            await ctx.reply(embed=error_embed(f"An error occurred: {e}"))


async def setup(bot):
    await bot.add_cog(Moderation(bot))
