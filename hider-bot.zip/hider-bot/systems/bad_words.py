import asyncio
import discord
from systems.mod_log import send_log_message


async def check_bad_words(message: discord.Message, settings: dict) -> bool:
    """Return True if a bad word was detected and the message was deleted."""
    if message.author.guild_permissions.manage_messages:
        return False

    raw = settings.get("bad_words", "")
    bad_words = [w.strip().lower() for w in raw.split(",") if w.strip()]
    if not bad_words:
        return False

    content = message.content.lower()
    found = next((w for w in bad_words if w in content), None)
    if not found:
        return False

    try:
        await message.delete()
    except Exception:
        pass

    embed = discord.Embed(
        title="Message Removed",
        description="Your message was removed because it contained a prohibited word.",
        color=0xED4245,
        timestamp=discord.utils.utcnow(),
    )
    embed.set_footer(text="Made by jesuislechef21")

    try:
        warn = await message.channel.send(content=f"<@{message.author.id}>", embed=embed)
        await asyncio.sleep(5)
        await warn.delete()
    except Exception:
        pass

    await send_log_message(
        message.guild,
        title="Bad Word Detected",
        color=0xED4245,
        fields=[
            {"name": "User", "value": f"{message.author} (<@{message.author.id}>)", "inline": True},
            {"name": "Channel", "value": f"<#{message.channel.id}>", "inline": True},
            {"name": "Word", "value": f"||`{found}`||", "inline": True},
        ],
    )
    return True
