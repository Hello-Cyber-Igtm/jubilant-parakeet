import discord
import time
from systems.mod_log import send_log_message
from utils.logger import logger


# spam_map[guild_id][user_id] = {"count": int, "first": float, "warned": bool}
spam_map: dict = {}


async def check_anti_spam(message: discord.Message, settings: dict) -> bool:
    """Return True if the message was detected as spam and deleted."""
    # Skip users with Manage Messages permission
    if message.author.guild_permissions.manage_messages:
        return False

    threshold = settings.get("spam_threshold", 5)
    interval = settings.get("spam_interval", 5)  # seconds
    guild_id = str(message.guild.id)
    user_id = str(message.author.id)
    now = time.time()

    if guild_id not in spam_map:
        spam_map[guild_id] = {}

    user_data = spam_map[guild_id].get(user_id, {"count": 0, "first": now, "warned": False})

    # Reset window if interval has passed
    if now - user_data["first"] > interval:
        spam_map[guild_id][user_id] = {"count": 1, "first": now, "warned": False}
        return False

    user_data["count"] += 1

    if user_data["count"] >= threshold:
        # Delete the triggering message
        try:
            await message.delete()
        except Exception:
            pass

        # Send one warning per spam window
        if not user_data["warned"]:
            user_data["warned"] = True
            spam_map[guild_id][user_id] = user_data

            embed = discord.Embed(
                title="Anti-Spam Warning",
                description=f"You have been flagged for spamming in **{message.guild.name}**. Please slow down.",
                color=0xFEE75C,
                timestamp=discord.utils.utcnow(),
            )
            embed.set_footer(text="Made by jesuislechef21")

            try:
                await message.author.send(embed=embed)
            except Exception:
                pass

            await send_log_message(
                message.guild,
                title="Anti-Spam Triggered",
                color=0xFEE75C,
                fields=[
                    {"name": "User", "value": f"{message.author} (<@{message.author.id}>)", "inline": True},
                    {"name": "Channel", "value": f"<#{message.channel.id}>", "inline": True},
                    {"name": "Messages", "value": f"{user_data['count']} in {interval}s", "inline": True},
                ],
            )

        return True

    spam_map[guild_id][user_id] = user_data
    return False
