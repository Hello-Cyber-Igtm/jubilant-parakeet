import discord
from database.queries import get_guild_settings
from utils.logger import logger
from typing import Optional, List


async def send_log_message(
    guild: discord.Guild,
    title: str,
    color: int = 0x5865F2,
    description: Optional[str] = None,
    fields: Optional[List[dict]] = None,
    thumbnail: Optional[str] = None,
):
    """Send a formatted embed to the guild's configured log channel."""
    try:
        settings = get_guild_settings(str(guild.id))
        log_channel_id = settings.get("log_channel")
        if not log_channel_id:
            return

        channel = guild.get_channel(int(log_channel_id))
        if not channel:
            return

        embed = discord.Embed(title=title, color=color, timestamp=discord.utils.utcnow())
        embed.set_footer(text="Made by jesuislechef21")

        if description:
            embed.description = description
        if thumbnail:
            embed.set_thumbnail(url=thumbnail)
        if fields:
            for field in fields:
                embed.add_field(
                    name=field.get("name", "\u200b"),
                    value=field.get("value", "\u200b"),
                    inline=field.get("inline", True),
                )

        await channel.send(embed=embed)
    except Exception as e:
        logger.error(f"Failed to send log message: {e}")
