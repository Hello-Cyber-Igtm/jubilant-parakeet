import re
import asyncio
import discord
from systems.mod_log import send_log_message

URL_PATTERN = re.compile(r"(https?://|www\.)\S+", re.IGNORECASE)
INVITE_PATTERN = re.compile(r"(discord\.gg|discord\.com/invite|discordapp\.com/invite)/\w+", re.IGNORECASE)


async def check_anti_link(message: discord.Message) -> bool:
    """Return True if a link was detected and the message was deleted."""
    if message.author.guild_permissions.manage_messages:
        return False

    if not (URL_PATTERN.search(message.content) or INVITE_PATTERN.search(message.content)):
        return False

    try:
        await message.delete()
    except Exception:
        pass

    embed = discord.Embed(
        title="Link Blocked",
        description="Your message was removed because links are not allowed in this server.",
        color=0xED4245,
        timestamp=discord.utils.utcnow(),
    )
    embed.set_footer(text="Made by jesuislechef21")

    try:
        warn = await message.channel.send(content=f"<@{message.author.id}>", embed=embed)
        await asyncio.sleep(5)
        await warn.delete()
    except Exception:
        pass

    await send_log_message(
        message.guild,
        title="Anti-Link Triggered",
        color=0xED4245,
        fields=[
            {"name": "User", "value": f"{message.author} (<@{message.author.id}>)", "inline": True},
            {"name": "Channel", "value": f"<#{message.channel.id}>", "inline": True},
            {"name": "Content", "value": message.content[:200], "inline": False},
        ],
    )
    return True
