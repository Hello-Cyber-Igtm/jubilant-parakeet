import os
import sys
import asyncio
import discord
from discord.ext import commands
from dotenv import load_dotenv
from database.queries import get_prefix
from utils.logger import logger

load_dotenv()

COGS = [
    "cogs.moderation",
    "cogs.utility",
    "cogs.config",
    "cogs.systems",
    "cogs.tickets",
    "cogs.help",
]


def get_dynamic_prefix(bot, message):
    """Return the per-guild prefix, falling back to '!' for DMs."""
    if not message.guild:
        return "$"
    return get_prefix(str(message.guild.id))


class HiderBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True
        intents.message_content = True
        intents.reactions = True

        super().__init__(
            command_prefix=get_dynamic_prefix,
            intents=intents,
            help_command=None,
            case_insensitive=True,
        )

    async def setup_hook(self):
        """Load all cogs on startup."""
        for cog in COGS:
            try:
                await self.load_extension(cog)
                logger.info(f"Loaded cog: {cog}")
            except Exception as e:
                logger.error(f"Failed to load cog {cog}: {e}")

    async def on_ready(self):
        logger.info(f"Logged in as {self.user} (ID: {self.user.id})")
        logger.info(f"Serving {len(self.guilds)} guild(s)")
        await self.change_presence(
            activity=discord.Activity(type=discord.ActivityType.watching, name="your server"),
            status=discord.Status.online,
        )

    async def on_guild_join(self, guild: discord.Guild):
        logger.info(f"Joined guild: {guild.name} ({guild.id})")
        from database.queries import get_guild_settings
        get_guild_settings(str(guild.id))

    async def on_member_join(self, member: discord.Member):
        from database.queries import get_guild_settings
        settings = get_guild_settings(str(member.guild.id))
        if not settings.get("welcome_channel"):
            return
        channel = member.guild.get_channel(int(settings["welcome_channel"]))
        if not channel:
            return
        raw = settings.get("welcome_message") or f"Welcome to **{member.guild.name}**, {{user}}! We now have **{{count}}** members."
        text = (
            raw.replace("{user}", member.mention)
               .replace("{username}", member.name)
               .replace("{server}", member.guild.name)
               .replace("{count}", str(member.guild.member_count))
        )
        embed = discord.Embed(title="Member Joined", description=text, color=0x57F287, timestamp=discord.utils.utcnow())
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.add_field(name="Account Created", value=f"<t:{int(member.created_at.timestamp())}:R>", inline=True)
        embed.add_field(name="Member Count", value=str(member.guild.member_count), inline=True)
        embed.set_footer(text="Made by jesuislechef21")
        await channel.send(embed=embed)

    async def on_member_remove(self, member: discord.Member):
        from database.queries import get_guild_settings
        settings = get_guild_settings(str(member.guild.id))
        if not settings.get("leave_channel"):
            return
        channel = member.guild.get_channel(int(settings["leave_channel"]))
        if not channel:
            return
        raw = settings.get("leave_message") or f"**{{username}}** has left **{member.guild.name}**. We now have **{{count}}** members."
        text = (
            raw.replace("{user}", member.name)
               .replace("{username}", member.name)
               .replace("{server}", member.guild.name)
               .replace("{count}", str(member.guild.member_count))
        )
        embed = discord.Embed(title="Member Left", description=text, color=0xED4245, timestamp=discord.utils.utcnow())
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text="Made by jesuislechef21")
        await channel.send(embed=embed)

    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        # Auto-moderation
        from database.queries import get_guild_settings
        from systems.anti_spam import check_anti_spam
        from systems.anti_link import check_anti_link
        from systems.bad_words import check_bad_words

        # Determine prefix and skip automod entirely for command messages
        from database.queries import get_prefix
        prefix = get_prefix(str(message.guild.id))
        is_command = message.content.startswith(prefix)

        if not is_command:
            try:
                settings = get_guild_settings(str(message.guild.id))

                if settings.get("anti_spam"):
                    if await check_anti_spam(message, settings):
                        return

                if settings.get("anti_link"):
                    if await check_anti_link(message):
                        return

                if settings.get("bad_words_filter") and settings.get("bad_words"):
                    if await check_bad_words(message, settings):
                        return
            except Exception as e:
                logger.error(f"Automod error: {e}")

        await self.process_commands(message)

    async def on_reaction_add(self, reaction: discord.Reaction, user: discord.User):
        if user.bot:
            return
        if not reaction.message.guild:
            return
        from database.queries import get_reaction_role
        emoji = str(reaction.emoji)
        rr = get_reaction_role(str(reaction.message.guild.id), str(reaction.message.id), emoji)
        if not rr:
            return
        guild = reaction.message.guild
        member = guild.get_member(user.id) or await guild.fetch_member(user.id)
        if not member:
            return
        role = guild.get_role(int(rr["role_id"]))
        if role:
            await member.roles.add(role)

    async def on_reaction_remove(self, reaction: discord.Reaction, user: discord.User):
        if user.bot:
            return
        if not reaction.message.guild:
            return
        from database.queries import get_reaction_role
        emoji = str(reaction.emoji)
        rr = get_reaction_role(str(reaction.message.guild.id), str(reaction.message.id), emoji)
        if not rr:
            return
        guild = reaction.message.guild
        member = guild.get_member(user.id) or await guild.fetch_member(user.id)
        if not member:
            return
        role = guild.get_role(int(rr["role_id"]))
        if role:
            await member.roles.remove(role)

    async def on_interaction(self, interaction: discord.Interaction):
        if not interaction.type == discord.InteractionType.component:
            return
        cid = interaction.data.get("custom_id", "")
        tickets_cog = self.get_cog("Tickets")
        if not tickets_cog:
            return
        if cid == "ticket_open":
            await tickets_cog.open_ticket(interaction)
        elif cid == "ticket_close":
            await tickets_cog.close_ticket_action(interaction)

    async def on_command_error(self, ctx: commands.Context, error):
        from utils.embed import error_embed
        if isinstance(error, commands.CommandNotFound):
            return
        if isinstance(error, commands.MissingRequiredArgument):
            cmd = ctx.command
            usage = cmd.usage or f"!{cmd.name}"
            await ctx.reply(embed=error_embed(f"Missing required argument.\n**Usage:** `{usage}`", "Invalid Usage"))
        elif isinstance(error, commands.BadArgument):
            await ctx.reply(embed=error_embed(f"Invalid argument: {error}", "Invalid Argument"))
        elif isinstance(error, commands.MemberNotFound):
            await ctx.reply(embed=error_embed("Member not found. Please mention a valid member or provide their ID.", "Member Not Found"))
        elif isinstance(error, commands.BotMissingPermissions):
            perms = ", ".join(error.missing_permissions)
            await ctx.reply(embed=error_embed(f"I am missing the following permissions: **{perms}**", "Missing Permissions"))
        elif isinstance(error, commands.CommandOnCooldown):
            await ctx.reply(embed=error_embed(f"This command is on cooldown. Try again in **{error.retry_after:.1f}s**.", "Cooldown"))
        else:
            logger.error(f"Unhandled command error in {ctx.command}: {error}")


async def main():
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        logger.error("DISCORD_TOKEN environment variable is not set.")
        sys.exit(1)

    bot = HiderBot()
    async with bot:
        await bot.start(token)


if __name__ == "__main__":
    asyncio.run(main())
