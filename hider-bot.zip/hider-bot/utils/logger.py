import logging
import sys
from datetime import datetime

# ANSI color codes
RESET = "\x1b[0m"
BOLD = "\x1b[1m"
RED = "\x1b[31m"
GREEN = "\x1b[32m"
YELLOW = "\x1b[33m"
BLUE = "\x1b[34m"
CYAN = "\x1b[36m"


class ColorFormatter(logging.Formatter):
    COLORS = {
        logging.DEBUG: CYAN,
        logging.INFO: GREEN,
        logging.WARNING: YELLOW,
        logging.ERROR: RED,
        logging.CRITICAL: RED + BOLD,
    }

    def format(self, record):
        color = self.COLORS.get(record.levelno, RESET)
        timestamp = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
        level = record.levelname
        msg = record.getMessage()
        return f"{BOLD}{color}[{timestamp}] [{level}]{RESET} {msg}"


def get_logger(name: str = "hider-bot") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(logging.DEBUG)
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(ColorFormatter())
        logger.addHandler(handler)
    return logger


logger = get_logger()
