import discord
from typing import Optional, List

# Standard embed colors
class Colors:
    PRIMARY = 0x5865F2
    SUCCESS = 0x57F287
    ERROR = 0xED4245
    WARNING = 0xFEE75C
    MODERATION = 0xFF5733
    NEUTRAL = 0x2B2D31


FOOTER_TEXT = "Made by jesuislechef21"


def base_embed(
    color: int = Colors.PRIMARY,
    title: Optional[str] = None,
    description: Optional[str] = None,
    footer: Optional[str] = FOOTER_TEXT,
    fields: Optional[List[dict]] = None,
    thumbnail: Optional[str] = None,
) -> discord.Embed:
    embed = discord.Embed(color=color)
    if title:
        embed.title = title
    if description:
        embed.description = description
    if footer:
        embed.set_footer(text=footer)
    if thumbnail:
        embed.set_thumbnail(url=thumbnail)
    if fields:
        for field in fields:
            embed.add_field(
                name=field.get("name", "\u200b"),
                value=field.get("value", "\u200b"),
                inline=field.get("inline", True),
            )
    embed.timestamp = discord.utils.utcnow()
    return embed


def success_embed(description: str, title: str = "Success") -> discord.Embed:
    return base_embed(color=Colors.SUCCESS, title=title, description=description)


def error_embed(description: str, title: str = "Error") -> discord.Embed:
    return base_embed(color=Colors.ERROR, title=title, description=description)


def warning_embed(description: str, title: str = "Warning") -> discord.Embed:
    return base_embed(color=Colors.WARNING, title=title, description=description)


def info_embed(
    description: str,
    title: str = "Information",
    fields: Optional[List[dict]] = None,
) -> discord.Embed:
    return base_embed(color=Colors.PRIMARY, title=title, description=description, fields=fields)


def moderation_embed(
    title: str,
    fields: Optional[List[dict]] = None,
    description: Optional[str] = None,
) -> discord.Embed:
    return base_embed(
        color=Colors.MODERATION,
        title=title,
        description=description,
        fields=fields or [],
    )
