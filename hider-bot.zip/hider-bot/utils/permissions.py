import discord
from discord.ext import commands
from utils.embed import error_embed


def check_permissions(member: discord.Member, *perms: str) -> bool:
    """Return True if the member has all the given permissions."""
    for perm in perms:
        if not getattr(member.guild_permissions, perm, False):
            return False
    return True


def can_moderate(moderator: discord.Member, target: discord.Member) -> bool:
    """Check if a moderator can act on a target member."""
    if target.id == target.guild.owner_id:
        return False
    if moderator.top_role <= target.top_role:
        return False
    return True


def bot_can_moderate(bot_member: discord.Member, target: discord.Member) -> bool:
    """Check if the bot can act on the target."""
    if target.id == target.guild.owner_id:
        return False
    if bot_member.top_role <= target.top_role:
        return False
    return True


async def send_no_permission(ctx: commands.Context, required: str):
    """Send a permission-denied embed."""
    await ctx.reply(
        embed=error_embed(
            f"You do not have permission to use this command.\n**Required:** {required}"
        )
    )
